const result = document.getElementById("result");
const reachResult = document.getElementById("reachResult");

let userLatitude = null;
let userLongitude = null;

function getLocation(successMessage) {
    if (!navigator.geolocation) {
        result.innerHTML = "❌ Your browser does not support location.";
        return;
    }

    result.innerHTML = "📍 Getting your location...";

    navigator.geolocation.getCurrentPosition(
        function(position) {
            userLatitude = position.coords.latitude;
            userLongitude = position.coords.longitude;

            if (successMessage) {
                successMessage();
            }
        },
        function() {
            result.innerHTML =
                "❌ Unable to get your location.<br>Please allow location permission and try again.";
        }
    );
}

function findLocation() {
    getLocation(function() {
        const mapURL =
            `https://www.google.com/maps?q=${userLatitude},${userLongitude}`;

        result.innerHTML = `
            <h2>📍 Your Current Location</h2>
            <p>Latitude: ${userLatitude.toFixed(6)}</p>
            <p>Longitude: ${userLongitude.toFixed(6)}</p>
            <a href="${mapURL}" target="_blank">🗺️ Open My Location</a>
        `;
    });
}

function findStations() {
    getLocation(function() {
        const mapURL =
            `https://www.google.com/maps/search/EV+charging+stations/@${userLatitude},${userLongitude},14z`;

        result.innerHTML = `
            <h2>⚡ Nearby EV Charging Stations</h2>
            <p>Stations around your current location can be viewed on Google Maps.</p>
            <a href="${mapURL}" target="_blank">🗺️ View Nearby Stations</a>
        `;
    });
}

function checkReach() {
    const battery = Number(document.getElementById("battery").value);
    const fullRange = Number(document.getElementById("range").value);
    const distance = Number(document.getElementById("distance").value);

    if (!battery || !fullRange || distance < 0) {
        reachResult.className = "card result-card warning";
        reachResult.innerHTML =
            "⚠️ Please enter valid Battery %, Full Battery Range and Station Distance.";
        return;
    }

    const availableRange = (battery / 100) * fullRange;
    const requiredBattery = (distance / fullRange) * 100;
    const batteryAtStation = battery - requiredBattery;

    if (availableRange >= distance) {
        reachResult.className = "card result-card success";
        reachResult.innerHTML = `
            <h3>✅ YES — You Can Reach!</h3>
            <p>Estimated available range: <strong>${availableRange.toFixed(1)} km</strong></p>
            <p>Station distance: <strong>${distance.toFixed(1)} km</strong></p>
            <p>Estimated battery on arrival: <strong>${Math.max(0, batteryAtStation).toFixed(1)}%</strong></p>
            <p>💡 Keep some extra battery as a safety buffer.</p>
        `;
    } else {
        reachResult.className = "card result-card danger";
        reachResult.innerHTML = `
            <h3>❌ NO — Current Range May Not Be Enough</h3>
            <p>Estimated available range: <strong>${availableRange.toFixed(1)} km</strong></p>
            <p>Station distance: <strong>${distance.toFixed(1)} km</strong></p>
            <p>Estimated extra range needed: <strong>${(distance - availableRange).toFixed(1)} km</strong></p>
            <p>🆘 Use the Backup Station button to search for another station.</p>
        `;
    }
}

function openBackupStations() {
    if (userLatitude !== null && userLongitude !== null) {
        const backupURL =
            `https://www.google.com/maps/search/EV+charging+stations/@${userLatitude},${userLongitude},13z`;

        window.open(backupURL, "_blank");
    } else {
        getLocation(function() {
            const backupURL =
                `https://www.google.com/maps/search/EV+charging+stations/@${userLatitude},${userLongitude},13z`;

            window.open(backupURL, "_blank");
        });
    }
}
